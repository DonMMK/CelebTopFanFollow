# CelebTopFanFollow

Run this worker on your existing Oracle VM. It uses Python 3.10+, systemd, SQLite, and the Telegram Bot API. There is no paid data provider, LLM, or incoming web server. Oracle hosting charges, if any, depend on your existing OCI account.

| Platform | What the free worker checks | Setup |
|---|---|---|
| Instagram | Photos, carousels, videos and Reels from professional accounts visible to Business Discovery | A Meta app, a Facebook Page linked to your own Instagram Business or Creator account, and a Facebook user token |
| TikTok | Recent posts shown in the public creator embed, usually videos. A slideshow is labelled only when the embed exposes a photo type. | No account or token. Preview your actual handles from the VM to check accessibility. |

Neither source monitors Stories. TikTok describes the public embed as a selection of up to ten recent videos. It can omit posts or refuse requests from the VM, and the worker records that as a failed check when the source is inaccessible. No CAPTCHA solving, login cookies or proxies are used. Meta Business Discovery is limited to professional accounts and excludes age-gated profiles. Use a small list and check the results before relying on it. Alerts can arrive after the next successful poll and can be missed if an item leaves the source's result window first.

In the Telegram chat you configured, open the bot's command menu or send `/watchlist`. In a group with multiple bots, use `/watchlist@YourBotName`. The reply groups the usernames by platform and shows which checks have succeeded, failed, are overdue, or haven't run yet. You can also see which platform is paused. Watchlist changes are made on the VM in `watchlist.json` and applied by restarting the service.

## Copy the bundle and install

Get the running VM's public IP from **OCI Console → Compute → Instances**. Use your private SSH key locally. For an Ubuntu image the default login is `ubuntu`. Substitute the key filename and IP:

```bash
chmod 600 ./oracle.key
scp -i ./oracle.key -o IdentitiesOnly=yes ./CelebTopFanFollow.zip ubuntu@YOUR_PUBLIC_IP:~/
ssh -i ./oracle.key -o IdentitiesOnly=yes ubuntu@YOUR_PUBLIC_IP
```

Then run this on the VM:

If the previous CelebTopFanFollow worker is already running, use `sudo systemctl stop celebtopfanfollow` first to pause its paid checks during the upgrade.

```bash
python3 -m zipfile -e ~/CelebTopFanFollow.zip ~/
cd ~/CelebTopFanFollow
sudo sh ./install.sh
sudoedit /etc/celebtopfanfollow/secrets.env
sudoedit /etc/celebtopfanfollow/watchlist.json
```

`install.sh` keeps your existing watchlist, secrets and database if you installed the previous bundle. It does not start or restart the worker. The free worker ignores the old Apify settings. You can remove `APIFY_TOKEN`, `max_usd_per_run`, and any Story intervals from the config. If you separately created a schedule in Apify, disable it there to stop those runs.

Example watchlist:

```json
{
  "instagram": ["natgeo"],
  "tiktok": ["tiktok"],
  "poll_minutes": {
    "instagram_feed": 60,
    "tiktok_feed": 60
  },
  "feed_results_per_profile": 10
}
```

Replace the example names with your own. Setting a platform's interval to `0` pauses it. An empty list is fine and the bot will still answer `/watchlist`. Existing installs keep their existing intervals.

## Reuse the Telegram bot

Keep your bot token and chat ID from the OpenClaw config or the previous bundle. OpenClaw may store the token as `channels.telegram.botToken`, a per-account setting, a token file, or `TELEGRAM_BOT_TOKEN`. Stop the old OpenClaw gateway before using the new worker to read bot commands. For the CLI install, run `openclaw gateway stop` as its owning user. If installed via Docker or a separate service, stop the specific old container or service. The same bot cannot have two active polling clients.

Add `TELEGRAM_BOT_TOKEN` and the numeric `TELEGRAM_CHAT_ID` to `secrets.env`. If you do not know the chat ID, open the bot and send `/start`, or send a command that mentions the bot in your group. While the worker and old gateway are stopped, run:

```bash
sudo systemd-run --wait --pipe --collect \
  --property=EnvironmentFile=/etc/celebtopfanfollow/secrets.env \
  /usr/bin/python3 /opt/celebtopfanfollow/worker.py --chat-id
```

If this returns HTTP 409, check if OpenClaw is still running. If it used a webhook and you are dedicating this bot to CelebTopFanFollow, use the same command with `--clear-telegram-webhook`, then send a new message and repeat the lookup. Run `--test-telegram` in place of `--chat-id` to test that the bot can send to your configured chat. If you use a broadcast channel for alerts and want interactive commands, configure a bot DM or group instead.

## Configure Instagram when ready

1. Create or use an Instagram professional account you control and connect it to a Facebook Page you manage. Create a Meta app and configure **Instagram API with Facebook Login**.
2. In [Graph API Explorer](https://developers.facebook.com/tools/explorer/), select your Meta app and generate a **Facebook user token** with `instagram_basic`, `instagram_manage_insights` and `pages_read_engagement`. Include `pages_show_list` to discover your Page. Depending on how the Page role was granted, Meta also lists `ads_management` or `ads_read`. See the [Business Discovery reference](https://developers.facebook.com/documentation/instagram-platform/instagram-graph-api/reference/ig-user/business_discovery).
3. Query `GET /me/accounts?fields=name,instagram_business_account{id,username}` in the Explorer. Copy the numeric `instagram_business_account.id` for **your own** linked account, rather than the Facebook Page ID or any celebrity's ID. If no linked account appears, check the Page connection and the grant for that Page.
4. Put that ID in `META_IG_USER_ID` and your Facebook user token in `META_ACCESS_TOKEN` in `secrets.env`. The optional `META_GRAPH_VERSION` defaults to `v27.0`. For ongoing use, follow [Meta's user-token documentation](https://developers.facebook.com/docs/facebook-login/guides/access-tokens/get-long-lived/) and replace the token when it expires.
5. Test with one target professional account using the preview below. TikTok works independently while you finish Meta setup.

## Verify and run

Check whether TikTok serves usable results to your Oracle VM. Run the same command with `--preview instagram_feed` after configuring Meta. Previews don't send alerts.

```bash
sudo systemd-run --wait --pipe --collect \
  --property=EnvironmentFile=/etc/celebtopfanfollow/secrets.env \
  /usr/bin/python3 /opt/celebtopfanfollow/worker.py --preview tiktok_feed

sudo systemctl enable celebtopfanfollow
sudo systemctl restart celebtopfanfollow
sudo journalctl -u celebtopfanfollow -f
```

Send `/watchlist` to the bot. For an end-to-end alert check, watch a public account you control, publish a new item after starting the worker, and wait for the next successful poll. The worker does not alert on items published before an account was added. If Telegram temporarily fails, unsent alerts stay in SQLite for retry. A message may occasionally be repeated if Telegram accepted it but the worker lost the response or stopped before recording delivery.

Once the new service works, you can remove the old OpenClaw and Jarvis-ish services. Preview a CLI removal with `openclaw uninstall --dry-run --all`, then remove the reviewed scopes if desired. Preserve any Jarvis-ish workbook or server data you still want, and keep the running VM and its SSH access.

[Oracle SSH help](https://docs.oracle.com/en-us/iaas/Content/Compute/Tasks/connect-to-linux-instance.htm) · [OpenClaw uninstall](https://docs.openclaw.ai/install/uninstall) · [TikTok creator embeds](https://developers.tiktok.com/docs/en/embed-creator-profiles) · [Telegram Bot API](https://core.telegram.org/bots/api)
